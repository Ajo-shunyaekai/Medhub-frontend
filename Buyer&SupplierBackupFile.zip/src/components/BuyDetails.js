import React from 'react'

const BuyDetails = () => {
    return (
        <>

        </>
    )
}

export default BuyDetails