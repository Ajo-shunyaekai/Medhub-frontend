import React from 'react'

const Tracking = () => {
    return (
        <div>Tracking</div>
    )
}

export default Tracking