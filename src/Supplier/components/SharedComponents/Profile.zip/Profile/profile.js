import React, { useEffect, useState } from "react";
import styles from "./profile.module.css";
import { MdOutlineAttachEmail } from "react-icons/md";
import { LuPhoneCall } from "react-icons/lu";
import { FaRegAddressCard } from "react-icons/fa";

const Profile = () => {
  const [supplierData, setSupplierData] = useState(null);

  // Fetching data from sessionStoragen
  useEffect(() => {
    const supplierId = sessionStorage.getItem("supplier_id");
    const supplierName = sessionStorage.getItem("supplier_name");
    const supplierEmail = sessionStorage.getItem("contact_person_email");
    const supplierMobileCode = sessionStorage.getItem("supplier_country_code");
    const supplierMobile = sessionStorage.getItem("supplier_mobile");
    const supplierAddress = sessionStorage.getItem("supplier_address");
    const supplierImage = sessionStorage.getItem("supplier_image");
    const supplierType = sessionStorage.getItem("supplier_type");


    const supplierPersonCountryCode = sessionStorage.getItem("contact_person_country_code");
    const supplierPersonMobileNo = sessionStorage.getItem("contact_person_mobile_no");
    const supplierPersonName = sessionStorage.getItem("contact_person_name");
    const supplierOperation = sessionStorage.getItem("country_of_operation");
    const supplierOrigin = sessionStorage.getItem("country_of_origin");
    const supplierDesignation = sessionStorage.getItem("designation");
    const supplierLicanseDate = sessionStorage.getItem("license_expiry_date");
    const supplierLicaneseNo = sessionStorage.getItem("license_no");


    const suppliertags = sessionStorage.getItem("tags");
    const supplierTaxNo = sessionStorage.getItem("tax_no");
    const supplierVatRegNo = sessionStorage.getItem("vat_reg_no");
    const supplierRegistrationNo = sessionStorage.getItem("registration_no");
    const supplierCertificateImage = sessionStorage.getItem("certificate_image");
    const supplierDescription = sessionStorage.getItem("description");
    const supplierLicenseImage = sessionStorage.getItem("license_image");
    const supplierPaymentTerms = sessionStorage.getItem("payment_terms");
    const supplierTaxImage = sessionStorage.getItem("tax_image");
    const supplierSalesName = sessionStorage.getItem("sales_person_name");

    if (supplierId) {
      setSupplierData({
        supplierId,
        supplierName,
        supplierEmail,
        supplierMobileCode,
        supplierMobile,
        supplierAddress,
        supplierImage,
        supplierType,
        supplierPersonCountryCode,
        supplierPersonMobileNo,
        supplierSalesName,
        supplierPersonName,
        supplierRegistrationNo,
        supplierOperation,
        supplierOrigin,
        supplierDesignation,
        supplierLicanseDate,
        supplierLicaneseNo,
        suppliertags,
        supplierTaxNo,
        supplierVatRegNo,
        supplierCertificateImage,
        supplierDescription,
        supplierLicenseImage,
        supplierPaymentTerms,
        supplierTaxImage,
      });
    }
  }, []);

  if (!supplierData) return <div>Loading...</div>;

  return (
    <div className={styles.container}>
      <div className={styles.profileHeadSection}>
        <div className={styles.MainHeading}>Profile</div>
        <div className={styles.EditButtonSection}>
          <span className={styles.editButton}>Edit</span>
        </div>
      </div>
      <div className={styles.profileContainer}>
        <div className={styles.imgSection}>
          {supplierData.supplierImage && (
            <img
              src={`${process.env.REACT_APP_SERVER_URL}uploads/supplier/supplierImage_files/${supplierData.supplierImage}`}
              alt="supplier Profile"
              className={styles.profileImage}
            />
          )}
        </div>
        <div className={styles.contentSection}>
          <div className={styles.companyNameSection}>
            <span className={styles.mainHead}>{supplierData.supplierName}&nbsp;({supplierData.supplierType})
            </span>
          </div>
          <div className={styles.contentIconSection}>
            <div className={styles.addressSection}>
              <div className={styles.iconSection}>
                <MdOutlineAttachEmail className={styles.icon} />
                <span className={styles.textSection}>{supplierData.supplierEmail}</span>
              </div>
              <div className={styles.iconSection}>
                <LuPhoneCall className={styles.icon} />
                <span className={styles.textSection}>
                  {supplierData.supplierMobileCode} {supplierData.supplierMobile}
                </span>
              </div>
            </div>
            <div className={styles.addressSection}>
              <div className={styles.iconSection}>
                <FaRegAddressCard className={styles.icon} />
                <div className={styles.addressContainers}>
                  <span className={styles.textSection}>{supplierData.supplierAddress}</span>
                  <span className={styles.textSection}>Near Vishal Mega Mart</span>
                  <span className={styles.textSection}>Gurugram Haryana</span>
                  <span className={styles.textSection}>122016</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* style the company container*/}
      <div className={styles.companySection}>
        <div className={styles.companyContainerSection}>
          <div className={styles.companyMainHeading}>Company Details</div>
          <div className={styles.companyDetailsSection}>
            <div className={styles.companyInnerContainer}>
              <div className={styles.companyDetails}>
                <div className={styles.companyHead}>Company Registration No.</div>
                <div className={styles.companyText}>{supplierData.supplierRegistrationNo}</div>
              </div>
              <div className={styles.companyDetails}>
                <div className={styles.companyHead}>VAT Registration No.</div>
                <div className={styles.companyText}>{supplierData.supplierVatRegNo}</div>
              </div>
              <div className={styles.companyDetails}>
                <div className={styles.companyHead}>Sales Person Name</div>
                <div className={styles.companyText}>{supplierData.supplierSalesName}</div>
              </div>
              <div className={styles.companyDetails}>
                <div className={styles.companyHead}>Country of Origin</div>
                <div className={styles.companyText}>{supplierData.supplierOrigin}</div>
              </div>
              <div className={styles.companyDetails}>
                <div className={styles.companyHead}>Country of Operation</div>
                <div className={styles.companyText}>{supplierData.supplierOperation}</div>
              </div>
            </div>
            <div className={styles.companyInnerContainer}>
              <div className={styles.companyDetails}>
                <div className={styles.companyHead}>Company License No.</div>
                <div className={styles.companyText}>{supplierData.supplierLicaneseNo}</div>
              </div>
              <div className={styles.companyDetails}>
                <div className={styles.companyHead}>License Expiry/ Renewal Date</div>
                <div className={styles.companyText}>{supplierData.supplierLicanseDate}</div>
              </div>
              <div className={styles.companyDetails}>
                <div className={styles.companyHead}>Company Tax No.</div>
                <div className={styles.companyText}>{supplierData.supplierTaxNo}</div>
              </div>
              <div className={styles.companyDetails}>
                <div className={styles.companyHead}>Tags</div>
                <div className={styles.companyText}>{supplierData.suppliertags}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className={styles.companySection}>
        <div className={styles.companyContainerSection}>
          <div className={styles.companyMainHeading}>Contact Details</div>
          <div className={styles.companyDetails}>
            <div className={styles.companyHead}>Contact Name</div>
            <div className={styles.companyText}>{supplierData.supplierPersonName}</div>
          </div>
          <div className={styles.companyDetails}>
            <div className={styles.companyHead}>Mobile No.</div>
            <div className={styles.companyText}>{supplierData.supplierPersonCountryCode} {supplierData.supplierPersonMobileNo}</div>
          </div>
          <div className={styles.companyDetails}>
            <div className={styles.companyHead}>Designation</div>
            <div className={styles.companyText}>{supplierData.supplierDesignation}</div>
          </div>
        </div>
      </div>
      {/* style the textarea container */}
      <div className={styles.textareaContainer}>
        <div className={styles.textareaSeaction}>
          <div className={styles.textareaHead}>About Company</div>
          <span className={styles.textareaContent}>{supplierData.supplierDescription}</span>
        </div>
        <div className={styles.textareaSeaction}>
          <div className={styles.textareaHead}>Payment Terms</div>
          <span className={styles.textareaContent}>{supplierData.supplierPaymentTerms}</span>
        </div>
        <div className={styles.textareaSeaction}>
          <div className={styles.textareaHead}>Business / Trade Activity Code</div>
          <span className={styles.textareaContent}>{supplierData.supplierDescription}</span>
        </div>
      </div>
    </div>
  );
};

export default Profile;
